

public class Test {

	public static void main(String[] args) {
	
      Son x=new Son("x",25,false,"ku");
      Son y=new Son("y",20,"ku");
      Son z=new Son("y",25,true,"kuet");
      Daughter a=new Daughter("a",z);
      Daughter b=new Daughter("b",21,true,"medical");
      Father p=new Father("P",60);
      Father q=new Father(new Father("Q",55));
      p.addChild(x);
      p.addChild(z,a);
      q.removeChild(b);
      q.addChild(y,b,a);
      p.geSonsDetails();
      System.out.println(q.getMarriedDaughsterDetails());
      
      
      
	}

}
